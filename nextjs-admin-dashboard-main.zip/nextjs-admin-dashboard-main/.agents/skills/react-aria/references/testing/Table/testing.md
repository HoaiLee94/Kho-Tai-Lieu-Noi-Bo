# Testing Table

## General setup

Table supports long press interactions on its rows in certain configurations. See the following sections on how to handle these behaviors in your tests.

- [Timers](../testing.md#timers)
- [Long press](../testing.md#simulating-long-press)

## Test utils

`@react-aria/test-utils` offers common table interaction testing utilities. Install it with your preferred package manager.

```bash
npm install @react-aria/test-utils --dev
```

<InlineAlert variant="notice">
  <Heading>Requirements</Heading>
  <Content>Please note that this library uses [@testing-library/dom@10](https://www.npmjs.com/package/@testing-library/dom) and [@testing-library/user-event@14](https://www.npmjs.com/package/@testing-library/user-event). This means that you need to be on React 18+ in order for these utilities to work.</Content>
</InlineAlert>

Initialize a `User` object at the top of your test file, and use it to create a `Table` pattern tester in your test cases. The tester has methods that you can call within your test to query for specific subcomponents or simulate common interactions.

```ts
// Table.test.ts
import {render, within} from '@testing-library/react';
import {User} from '@react-aria/test-utils';

let testUtilUser = new User({
  interactionType: 'mouse',
  advanceTimer: jest.advanceTimersByTime
});
// ...

it('Table can toggle row selection', async function () {
  // Render your test component/app and initialize the table tester
  let {getByTestId} = render(
    <Table data-testid="test-table" selectionMode="multiple">
    ...
    </Table>
  );
  let tableTester = testUtilUser.createTester('Table', {root: getByTestId('test-table')});
  expect(tableTester.getSelectedRows()).toHaveLength(0);

  await tableTester.toggleSelectAll();
  expect(tableTester.getSelectedRows()).toHaveLength(10);

  await tableTester.toggleRowSelection({row: 2});
  expect(tableTester.getSelectedRows()).toHaveLength(9);
  let checkbox = within(tableTester.getRows()[2]).getByRole('checkbox');
  expect(checkbox).not.toBeChecked();

  await tableTester.toggleSelectAll();
  expect(tableTester.getSelectedRows()).toHaveLength(10);
  expect(checkbox).toBeChecked();

  await tableTester.toggleSelectAll();
  expect(tableTester.getSelectedRows()).toHaveLength(0);
});
```

## API

### User

### TableTester

## Testing FAQ

<PatternTestingFAQ patternName="table"/>
