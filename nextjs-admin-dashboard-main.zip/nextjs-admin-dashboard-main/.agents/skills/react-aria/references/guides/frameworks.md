# Framework setup

Learn how to integrate React Aria with your framework.

<Tabs
  aria-label="Frameworks"
  density="compact"
>
  <TabList><Tab id="next"><Nextjs/><Text>Next.js</Text></Tab><Tab id="react-router"><ReactRouter/><Text>React Router</Text></Tab><Tab id="parcel"><Parcel/><Text>Parcel</Text></Tab><Tab id="vite"><Vite/><Text>Vite</Text></Tab><Tab id="webpack"><Webpack/><Text>webpack</Text></Tab><Tab id="rollup"><Rollup/><Text>Rollup</Text></Tab><Tab id="esbuild"><ESBuild/><Text>ESBuild</Text></Tab></TabList>

  <TabPanel id="next">
    To integrate with Next.js (app router), ensure the locale on the server matches the client.

    <StepList>
      <Step>
        <Counter/>In your root layout, determine the user's preferred language and set the `lang` and `dir` attributes on the `<html>` element.

        ```tsx
        // app/layout.tsx
        import {headers} from 'next/headers';
        import {isRTL} from 'react-aria-components/I18nProvider';
        import {ClientProviders} from './provider';

        export default async function RootLayout({children}) {
          // Get the user's preferred language from the Accept-Language header.
          // You could also get this from a database, URL param, etc.
          const acceptLanguage = (await headers()).get('accept-language');
          const lang = acceptLanguage?.split(/[,;]/)[0] || 'en-US';

          return (
            <html lang={lang} dir={isRTL(lang) ? 'rtl' : 'ltr'}>
              <body>
                <ClientProviders lang={lang}>
                  {children}
                </ClientProviders>
              </body>
            </html>
          );
        }
        ```
      </Step>

      <Step>
        <Counter/>Create `app/provider.tsx`. This should render an `I18nProvider` to set the locale used by React Aria.

        ```tsx
        // app/provider.tsx
        "use client";

        import {I18nProvider} from 'react-aria-components/I18nProvider';

        export function ClientProviders({lang, children}) {
          return (
            <I18nProvider locale={lang}>
              {children}
            </I18nProvider>
          );
        }
        ```
      </Step>

      <Step>
        <Counter/>If you are using a [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) (CSP) with a nonce, add a `<meta property="csp-nonce">` tag to your document head, setting the `content` attribute to the generated nonce value. React Aria automatically reads the nonce from this tag.
      </Step>
    </StepList>
  </TabPanel>

  <TabPanel id="react-router">
    To integrate with React Router (framework mode), ensure the locale on the server matches the client, and exclude localized strings from the client bundle. If you're using declarative mode, choose your bundler above.

    <StepList>
      <Step>
        <Counter/>Run the following command to reveal [entry.server.tsx](https://remix.run/docs/en/main/file-conventions/entry.server) if you don't already have one.

        ```bash
        npx react-router reveal
        ```
      </Step>

      <Step>
        <Counter/>Make the following changes to `entry.server.tsx`. This will set the locale used by React Aria using the `Accept-Language` HTTP header, and inject the localized strings for the user's language into the HTML.

        ```tsx
        // app/entry.server.tsx
        import type {EntryContext} from 'react-router';
        import {ServerRouter} from 'react-router';
        import {renderToPipeableStream} from 'react-dom/server';
        /*- begin highlight -*/
        import {I18nProvider} from 'react-aria-components/I18nProvider';
        import {getLocalizationScript} from 'react-aria-components/i18n';
        /*- end highlight -*/

        export default async function handleRequest(
          request: Request,
          responseStatusCode: number,
          responseHeaders: Headers,
          remixContext: EntryContext,
        ) {
          // Get the requested language (e.g. from headers, URL param, database, etc.)
          /*- begin highlight -*/
          const acceptLanguage = request.headers.get('accept-language');
          const lang = acceptLanguage?.split(/[,;]/)[0] || 'en-US';
          /*- end highlight -*/

          return new Promise((resolve, reject) => {
            const {pipe, abort} = renderToPipeableStream(
              {/* Wrap in an I18nProvider to set locale used by React Aria. */}
              {/*- begin highlight -*/}
              <I18nProvider locale={lang}>
              {/*- end highlight -*/}
                <ServerRouter
                  context={routerContext}
                  url={request.url} />
              </I18nProvider>,
              {
                /*- begin highlight -*/
                // Inject localized strings into the HTML.
                bootstrapScriptContent: getLocalizationScript(lang),
                /*- end highlight -*/
                // ...
              }
            );
          });
        }
        ```
      </Step>

      <Step>
        <Counter/>In your root layout, set the `lang` and `dir` attributes on the `<html>` element, and render a `RouterProvider` to configure React Aria links to use React Router.

        ```tsx
        // app/root.tsx
        import {useLocale} from 'react-aria-components/I18nProvider';

        export function Layout({children}) {
          /*- begin highlight -*/
          let {locale, direction} = useLocale();
          /*- end highlight -*/

          return (
            /*- begin highlight -*/
            <html lang={locale} dir={direction}>
            {/*- end highlight -*/}
              <head>
                {/* ... */}
              </head>
              <body>
                {children}
                {/* ... */}
              </body>
            </html>
          );
        }
        ```
      </Step>

      <Step>
        <Counter/>Install the locale optimization bundler plugin. This will omit the localized strings from the JavaScript bundle. The strings for the user's language are injected into the HTML instead.

        ```bash
        npm install @react-aria/optimize-locales-plugin
        ```
      </Step>

      <Step>
        <Counter/>Edit `vite.config.ts` to add the plugin.

        ```ts
        // vite.config.ts
        import {reactRouter} from "@react-router/dev/vite";
        import {defineConfig} from 'vite';
        /*- begin highlight -*/
        import localesPlugin from '@react-aria/optimize-locales-plugin';
        /*- end highlight -*/

        export default defineConfig({
          plugins: [
            reactRouter(),
            // Don't include any locale strings in the client JS bundle.
            /*- begin highlight -*/
            {...localesPlugin.vite({locales: []}), enforce: 'pre'}
            /*- end highlight -*/
          ],
        });
        ```
      </Step>

      <Step>
        <Counter/>If you are using a [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) (CSP) with a nonce, add a `<meta property="csp-nonce">` tag to your document head, setting the `content` attribute to the generated nonce value. React Aria automatically reads the nonce from this tag.
      </Step>
    </StepList>
  </TabPanel>

  <TabPanel id="parcel">
    To integrate with a client-only Parcel SPA, and optimize the client bundle to include localized strings for your supported languages.

    <StepList>
      <Step>
        <Counter/>By default, React Aria includes localized strings for 30+ languages. To optimize the JavaScript bundle to include only your supported languages, install our bundler plugin.

        ```bash
        npm install @react-aria/parcel-resolver-optimize-locales
        ```
      </Step>

      <Step>
        <Counter/>Add the following to your `.parcelrc`.

        ```json
        {
          "extends": "@parcel/config-default",
          "resolvers": ["@react-aria/parcel-resolver-optimize-locales", "..."]
        }
        ```
      </Step>

      <Step>
        <Counter/>In your project root `package.json`, add a `"locales"` field containing the languages you want to support.

        ```json
        {
          "locales": ["en-US", "fr-FR"]
        }
        ```
      </Step>

      <Step>
        <Counter/>If you are using a [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) (CSP) with a nonce, add a `<meta property="csp-nonce">` tag to your document head, setting the `content` attribute to the generated nonce value. React Aria automatically reads the nonce from this tag.
      </Step>
    </StepList>
  </TabPanel>

  <TabPanel id="vite">
    To integrate with a client-only Vite SPA, and optimize the client bundle to include localized strings for your supported languages.

    <StepList>
      <Step>
        <Counter/>By default, React Aria includes localized strings for 30+ languages. To optimize the JavaScript bundle to include only your supported languages, install our bundler plugin.

        ```bash
        npm install @react-aria/optimize-locales-plugin
        ```
      </Step>

      <Step>
        <Counter/>Edit `vite.config.ts` to add the plugin, and configure the `locales` parameter.

        ```ts
        // vite.config.ts
        import {defineConfig} from 'vite';
        import optimizeLocales from '@react-aria/optimize-locales-plugin';

        export default defineConfig({
          plugins: [
            {
              ...optimizeLocales.vite({
                locales: ['en-US', 'fr-FR']
              }),
              enforce: 'pre'
            }
          ],
        });
        ```
      </Step>

      <Step>
        <Counter/>If you are using a [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) (CSP) with a nonce, configure [`html.cspNonce`](https://vite.dev/config/shared-options.html#html-cspnonce) in `vite.config.ts`. React Aria automatically reads the nonce that Vite injects.
      </Step>
    </StepList>
  </TabPanel>

  <TabPanel id="webpack">
    To integrate with a client-only webpack SPA, and optimize the client bundle to include localized strings for your supported languages.

    <StepList>
      <Step>
        <Counter/>By default, React Aria includes localized strings for 30+ languages. To optimize the JavaScript bundle to include only your supported languages, install our bundler plugin.

        ```bash
        npm install @react-aria/optimize-locales-plugin
        ```
      </Step>

      <Step>
        <Counter/>Edit `webpack.config.ts` to add the plugin, and configure the `locales` parameter.

        ```ts
        // webpack.config.js
        const optimizeLocales = require('@react-aria/optimize-locales-plugin');

        module.exports = {
          // ...
          plugins: [
            optimizeLocales.webpack({
              locales: ['en-US', 'fr-FR']
            })
          ]
        };
        ```
      </Step>

      <Step>
        <Counter/>If you are using a [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) (CSP) with a nonce, configure [`__webpack_nonce__`](https://webpack.js.org/guides/csp/) in your entry script. React Aria automatically reads the nonce from the webpack global.
      </Step>
    </StepList>
  </TabPanel>

  <TabPanel id="rollup">
    To integrate with a client-only Rollup SPA, and optimize the client bundle to include localized strings for your supported languages.

    <StepList>
      <Step>
        <Counter/>By default, React Aria includes localized strings for 30+ languages. To optimize the JavaScript bundle to include only your supported languages, install our bundler plugin.

        ```bash
        npm install @react-aria/optimize-locales-plugin
        ```
      </Step>

      <Step>
        <Counter/>Edit `rollup.config.js` to add the plugin, and configure the `locales` parameter.

        ```ts
        // rollup.config.js
        import optimizeLocales from '@react-aria/optimize-locales-plugin';

        export default {
          // ...
          plugins: [
            optimizeLocales.rollup({
              locales: ['en-US', 'fr-FR']
            })
          ]
        };
        ```
      </Step>

      <Step>
        <Counter/>If you are using a [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) (CSP) with a nonce, add a `<meta property="csp-nonce">` tag to your document head, setting the `content` attribute to the generated nonce value. React Aria automatically reads the nonce from this tag.
      </Step>
    </StepList>
  </TabPanel>

  <TabPanel id="esbuild">
    To integrate with a client-only ESBuild SPA, and optimize the client bundle to include localized strings for your supported languages.

    <StepList>
      <Step>
        <Counter/>By default, React Aria includes localized strings for 30+ languages. To optimize the JavaScript bundle to include only your supported languages, install our bundler plugin.

        ```bash
        npm install @react-aria/optimize-locales-plugin
        ```
      </Step>

      <Step>
        <Counter/>Edit your build script to add the plugin, and configure the `locales` parameter.

        ```ts
        import {build} from 'esbuild';
        import optimizeLocales from '@react-aria/optimize-locales-plugin';

        build({
          // ...
          plugins: [
            optimizeLocales.esbuild({
              locales: ['en-US', 'fr-FR']
            })
          ]
        });
        ```
      </Step>

      <Step>
        <Counter/>If you are using a [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) (CSP) with a nonce, add a `<meta property="csp-nonce">` tag to your document head, setting the `content` attribute to the generated nonce value. React Aria automatically reads the nonce from this tag.
      </Step>
    </StepList>
  </TabPanel>
</Tabs>
