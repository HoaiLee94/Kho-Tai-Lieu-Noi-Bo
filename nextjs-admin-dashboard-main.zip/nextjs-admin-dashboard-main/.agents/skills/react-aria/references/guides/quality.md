# Quality

React Aria is built around three core principles: **Accessibility**, **Internationalization**, and **Interactions**. Learn how to apply these tools to build high quality UIs that work for everyone, everywhere, and on every device.

## Accessibility

Accessible applications are usable by everyone, including people with disabilities. Accessibility benefits all users — not just those using assistive technologies — by improving efficiency, consistency, and usability.

React Aria provides built-in support for screen readers and keyboard navigation, following the [WAI-ARIA](https://www.w3.org/TR/wai-aria-1.2/) and [ARIA Authoring Practices](https://www.w3.org/WAI/ARIA/apg/) guidelines. It supplies the correct semantics via ARIA roles and attributes, handles keyboard and pointer events, manages focus, and provides screen reader announcements. React Aria components are tested across a wide variety of devices, browsers, and screen readers.

Be sure to create an accessible visual design with meaningful labels, sufficient [color contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast) and [hit target sizes](https://www.w3.org/WAI/WCAG22/Understanding/target-size-enhanced), visible [focus rings](https://www.w3.org/WAI/WCAG22/Understanding/focus-appearance), and respect [motion preferences](https://www.w3.org/WAI/WCAG21/Understanding/animation-from-interactions). The [WCAG guidelines](https://www.w3.org/WAI/WCAG22/Understanding/) are a good resource to reference when designing and building components with React Aria.

### Labeling

Most components should have a visible label, which is usually provided by rendering a `<Label>` element within it. This is associated with the component automatically.

```tsx
import {TextField, Label, Input} from 'react-aria-components/TextField';

<TextField>
  {/*- begin highlight -*/}
  <Label>First name</Label>
  {/*- end highlight -*/}
  <Input />
</TextField>
```

When a component doesn't have a visible label, it must have an [aria-label](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Attributes/aria-label) or [aria-labelledby](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Attributes/aria-labelledby) prop to provide an accessible name.

```tsx
import {ProgressBar} from 'react-aria-components/ProgressBar';

<ProgressBar
  /*- begin highlight -*/
  aria-label="Processing" />
  /*- end highlight -*/
```

### Supported screen readers

React Aria is tested across a variety of devices, browsers, and screen readers.

- [VoiceOver on macOS](https://www.apple.com/accessibility/mac/vision/) in Safari and Chrome
- [JAWS](https://www.freedomscientific.com/products/software/jaws/) on Windows in Firefox and Chrome
- [NVDA](https://www.nvaccess.org) on Windows in Firefox and Chrome
- [VoiceOver on iOS](https://www.apple.com/accessibility/iphone/vision/)
- [TalkBack](https://www.android.com/accessibility/) on Android in Chrome

### Automated testing

Automated accessibility testing tools sometimes catch false positives in React Aria. These are documented in our [wiki](https://github.com/adobe/react-spectrum/wiki/Known-accessibility-false-positives).

## Internationalization

Localization is an important way to make your application usable by the widest number of people. React Aria includes localized strings for 30+ languages, handles dates and numbers in many calendar and numbering systems, and supports right-to-left interactions (e.g. keyboard navigation).

Make sure your design supports right-to-left layout, and adapts to different languages (e.g. using appropriate fonts). Modern CSS grid and flex layouts are automatically mirrored depending on the direction, and [logical properties](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_logical_properties_and_values) can be used to adapt margins, paddings, borders, etc.

### Setting the locale

React Aria automatically detects the user's current language by default. Use the `I18nProvider` component to set the locale to a specific value. You should also set the `lang` and `dir` attributes on the root-most element of your application.

```tsx
import {I18nProvider, useLocale} from 'react-aria-components/I18nProvider';

<I18nProvider locale="fr-FR">
  <App />
</I18nProvider>

function App() {
  let {locale, direction} = useLocale();

  return (
    <html lang={locale} dir={direction}>
      {/* your app here */}
    </html>
  );
}
```

### Supported locales

<ul style={{columnWidth: 200, paddingLeft: 16, fontFamily: 'adobe-clean-spectrum-vf'}}>
  <li>Arabic (United Arab Emirates) (`ar-AE`)</li>
  <li>Bulgarian (Bulgaria) (`bg-BG`)</li>
  <li>Chinese (Simplified) (`zh-CN`)</li>
  <li>Chinese (Traditional) (`zh-TW`)</li>
  <li>Croatian (Croatia) (`hr-HR`)</li>
  <li>Czech (Czech Republic) (`cs-CZ`)</li>
  <li>Danish (Denmark) (`da-DK`)</li>
  <li>Dutch (Netherlands) (`nl-NL`)</li>
  <li>English (Great Britain) (`en-GB`)</li>
  <li>English (United States) (`en-US`)</li>
  <li>Estonian (Estonia) (`et-EE`)</li>
  <li>Finnish (Finland) (`fi-FI`)</li>
  <li>French (Canada) (`fr-CA`)</li>
  <li>French (France) (`fr-FR`)</li>
  <li>German (Germany) (`de-DE`)</li>
  <li>Greek (Greece) (`el-GR`)</li>
  <li>Hebrew (Israel) (`he-IL`)</li>
  <li>Hungarian (Hungary) (`hu-HU`)</li>
  <li>Italian (Italy) (`it-IT`)</li>
  <li>Japanese (Japan) (`ja-JP`)</li>
  <li>Korean (Korea) (`ko-KR`)</li>
  <li>Latvian (Latvia) (`lv-LV`)</li>
  <li>Lithuanian (Lithuania) (`lt-LT`)</li>
  <li>Norwegian (Norway) (`nb-NO`)</li>
  <li>Polish (Poland) (`pl-PL`)</li>
  <li>Portuguese (Portugal) (`pt-PT`)</li>
  <li>Portuguese (Brazil) (`pt-BR`)</li>
  <li>Romanian (Romania) (`ro-RO`)</li>
  <li>Russian (Russia) (`ru-RU`)</li>
  <li>Serbian (Serbia) (`sr-SP`)</li>
  <li>Slovakian (Slovakia) (`sk-SK`)</li>
  <li>Slovenian (Slovenia) (`sl-SI`)</li>
  <li>Spanish (Spain) (`es-ES`)</li>
  <li>Swedish (Sweden) (`sv-SE`)</li>
  <li>Turkish (Turkey) (`tr-TR`)</li>
  <li>Ukrainian (Ukraine) (`uk-UA`)</li>
</ul>

## Interactions

Modern web apps run on everything from desktops to mobile devices to TVs, with users interacting through mouse, touch, keyboard, and assistive technologies. React Aria normalizes these differences, delivering consistent “press”, “hover”, and “focus” behaviors across all browsers and input types.

React Aria components provide data attributes and render props to style these states:

- `data-pressed` – like the `:active` pseudo class, but removed when the pointer is dragged off.
- `data-hovered` – like `:hover`, but not applied on touch devices, preventing sticky hover states.
- `data-focus-visible` – like `:focus-visible`, but not on input click or programmatic focus.

These states also come with corresponding events such as `onPress` and `onHoverStart`. To use these events in your own custom components, see hooks such as [usePress](usePress.md), [useHover](useHover.md), [useMove](useMove.md), and [useFocusRing](useFocusRing.md).

Read our blog post series to learn more about the intricacies behind these interactions.

- [Building a Button Part 1: Press Events](blog/building-a-button-part-1.md)
- [Building a Button Part 2: Hover Interactions](blog/building-a-button-part-2.md)
- [Building a Button Part 3: Keyboard Focus Behavior](blog/building-a-button-part-3.md)

Higher level interaction patterns such as [selection](selection.md) and [drag and drop](dnd.md) are also built on top of these low level primitives.
